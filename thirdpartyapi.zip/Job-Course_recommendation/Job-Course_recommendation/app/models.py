# models.py
from .database import Base
from sqlalchemy import Column, Integer, String ,Text

class User(Base):  # FIXED: Capital 'U'
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(225), nullable=False)
    skill = Column(String(225), nullable=False)
    resume = Column(Text, nullable=False)
    certificates = Column(String(225), nullable=False)