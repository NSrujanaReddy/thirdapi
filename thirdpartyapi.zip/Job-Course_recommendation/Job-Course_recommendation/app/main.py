from fastapi import FastAPI, Depends, status, UploadFile, File
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from PyPDF2 import PdfReader
import os
from fastapi import HTTPException
from .import models, schemas, database
from .database import get_db
from google import generativeai as genai


models.Base.metadata.create_all(bind=database.engine)

app = FastAPI(title="Job_Course_Recommendation")

@app.post("/users/", response_model=schemas.Users, status_code=status.HTTP_201_CREATED)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    try:
        db_user = models.User(**user.dict())
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
        return db_user
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def parsingpdf(file_loactaion):
    reader=PdfReader(file_loactaion)
    text=[]
    for page in reader.pages:
        text.append(page.extract_text())
    return '\n'.join(text)

@app.post("/parsing")
async def resume_parsing(file: UploadFile = File(...)):
    file_location = f"temp_{file.filename}"
    with open(file_location, "wb") as f:
        f.write(await file.read())
    extract_text = parsingpdf(file_location)
    os.remove(file_location)
    return JSONResponse(content={"extracted_text": extract_text})
GOOGLE_API_KEY="AIzaSyDk19N6Qgu7cUCw1zsG5iCjw5Suag29-RI"
genai.configure(api_key=GOOGLE_API_KEY)

@app.post('/suggestjob/{user_id}',response_model=schemas.JobTitle)
async def job_suggestion(user_id: int,db:Session=Depends(get_db)):
    if not GOOGLE_API_KEY:
        return JSONResponse(content={"error":'Google API key not probvided'},status_code=status.HTTP_400_BAD_REQUEST)
    user=db.query(models.User).filter(models.User.id==user_id).first()
    if not user:
        return JSONResponse(content={"error":"user not found"},status_code=status.HTTP_404_NOT_FOUND)
    if not user.resume:
        return JSONResponse(content={"error":"resume not uploaded"},status_code=status.HTTP_400_BAD_REQUEST)
    try:
        model=genai.GenerativeModel("gemini-2.0-flash")
        prompt=f"give me a promt based on my resume only one job{user.resume}"
        response=await model.generate_content_async(prompt)
        job_title=response.text.strip()
        return JSONResponse(content={"job_title":job_title,"user_id":user_id})
    except Exception as e:
        return JSONResponse(content={"error":str(e)},status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)