from pydantic import BaseModel # type: ignore
from typing import Optional
class UserBase(BaseModel):
    name:str
    skill:Optional[str] =None
    resume:Optional[str] =None
    certificates:Optional[str]=None


class UserCreate(UserBase):
    pass

class Users(UserBase):
    id:int
    class config:
        orm_mode=True
        from_attributes=True
class JobTitle(UserBase):
    id:int
    jobtitle: str