package com.example.thirdpartyapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThirdpartyapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThirdpartyapiApplication.class, args);
	}

}
