package com.example.thirdpartyapi.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/app")
public class JobRecommendation {

    @Autowired
    private RestTemplate restTemplate;

    @PostMapping("/jobs")
    public ResponseEntity<?> suggestJob(@RequestBody JobRequest req) {
        try {
            String url = "https://jsearch.p.rapidapi.com/search";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("x-rapidapi-key", "68c4f9fd28msh8a35f415e04163dp16835fjsnaac8aaf8bef4");
            headers.set("x-rapidapi-host", "jsearch.p.rapidapi.com");

            Map<String, Object> body = new HashMap<>();
            body.put("query", req.getJobrecom());
            body.put("page", 1);
            body.put("num_pages", 1); // corrected key from "num_page" to "num_pages" based on API docs

            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);
            ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);

            return ResponseEntity.ok(response.getBody());

        } catch (Exception e) {
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error: " + e.getMessage());
        }
    }

    // DTO class for request body
    public static class JobRequest {
        private int userid;
        private String jobrecom;

        public int getUserid() {
            return userid;
        }

        public void setUserid(int userid) {
            this.userid = userid;
        }

        public String getJobrecom() {
            return jobrecom;
        }

        public void setJobrecom(String jobrecom) {
            this.jobrecom = jobrecom;
        }
    }
}
