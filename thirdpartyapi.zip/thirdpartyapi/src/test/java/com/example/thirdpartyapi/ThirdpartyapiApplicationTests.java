package com.example.thirdpartyapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThirdpartyapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
